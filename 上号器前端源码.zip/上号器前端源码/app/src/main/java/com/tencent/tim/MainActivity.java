package com.tencent.tim;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import android.content.SharedPreferences;
import android.content.Intent;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import android.app.AlertDialog;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
import com.tencent.open.agent.AgentActivity;
import android.widget.EditText;
import android.view.LayoutInflater;
import android.os.Environment;
import android.content.DialogInterface;
import android.os.Build;
import android.provider.Settings;
import android.net.Uri;

public class MainActivity extends Activity {

    private static final String PACKAGE_NAME = "com.tencent.mobileqq";
    private RadioGroup modeRadioGroup;
    private RadioButton radioCaptureMode;
    private RadioButton radioLoginMode;
    private RadioButton radioHangUpMode;
    private Button hideButton;
    private Button showButton;
    private Button testNumberButton;
    private Button filterButton;
    private Button testPageButton;
    private Button selectGameButton;
    private Button jumpWebButton;
    private Button jumpWebRightButton;
    private List<GameItem> gameList = new ArrayList<>();
    private String selectedGameUrl = "";
    private String selectedGameName = "";
    private static final String SELECTED_GAME_URL_KEY = "selected_game_url";
    private static final String SELECTED_GAME_NAME_KEY = "selected_game_name";

    class GameItem {
        String iconUrl;
        String name;
        String url;

        GameItem(String iconUrl, String name, String url) {
            this.iconUrl = iconUrl;
            this.name = name;
            this.url = url;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initViews();
        setupClickListeners();
        loadSavedMode();
        loadSelectedGame();
        loadGameListFromServer();
    }

    private void initViews() {
        modeRadioGroup = findViewById(R.id.modeRadioGroup);
        radioCaptureMode = findViewById(R.id.radio_capture_mode);
        radioLoginMode = findViewById(R.id.radio_login_mode);
        radioHangUpMode = findViewById(R.id.radio_hang_up_mode);
        testNumberButton = findViewById(R.id.testNumberButton);
        filterButton = findViewById(R.id.filterButton);

        hideButton = findViewById(R.id.hideButton);
        showButton = findViewById(R.id.showButton);
        testPageButton = findViewById(R.id.testPageButton);
        selectGameButton = findViewById(R.id.selectGameButton);
        jumpWebButton = findViewById(R.id.jumpWebButton);
        jumpWebRightButton = findViewById(R.id.jumpWebRightButton);
        updateSelectGameButtonText();
    }

    private void setupClickListeners() {
        modeRadioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId == R.id.radio_capture_mode) {
                    saveMode("capture");
                    Toast.makeText(MainActivity.this, "已切换到抓号模式", Toast.LENGTH_SHORT).show();
                } else if (checkedId == R.id.radio_login_mode) {
                    saveMode("login");
                    Toast.makeText(MainActivity.this, "已切换到上号模式", Toast.LENGTH_SHORT).show();
                } else if (checkedId == R.id.radio_hang_up_mode) {
                    saveMode("hang_up");
                    Toast.makeText(MainActivity.this, "已切换到挂机模式", Toast.LENGTH_SHORT).show();
                }
            }
        });

        hideButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    hidePackage(PACKAGE_NAME);
                    Toast.makeText(MainActivity.this, "隐藏成功", Toast.LENGTH_SHORT).show();
                } catch (IOException e) {
                    Toast.makeText(MainActivity.this, "隐藏失败，请给root再重试", Toast.LENGTH_SHORT).show();
                }
            }
        });

        showButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    unhidePackage(PACKAGE_NAME);
                    Toast.makeText(MainActivity.this, "恢复成功", Toast.LENGTH_SHORT).show();
                } catch (IOException e) {
                    Toast.makeText(MainActivity.this, "恢复失败", Toast.LENGTH_SHORT).show();
                }
            }
        });

        testNumberButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "切换到验号模式", Toast.LENGTH_SHORT).show();
                showFileInputDialog();
            }
        });

        filterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, FilterActivity.class);
                startActivity(intent);
            }
        });

        testPageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences sharedPreferences = getSharedPreferences("myPrefs", MODE_PRIVATE);
                String mode = sharedPreferences.getString("pd_key", "capture");

                Intent intent = new Intent(MainActivity.this, AgentActivity.class);
                intent.putExtra("mode", mode);
                startActivity(intent);
            }
        });

        selectGameButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showGameSelectionDialog();
            }
        });

        jumpWebButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "按钮已触发，跳转网页", Toast.LENGTH_SHORT).show();
                String url = "https://tsukichen.click";
                Intent webIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                Intent chooser = Intent.createChooser(webIntent, "选择浏览器打开");
                startActivity(chooser);
            }
        });

        jumpWebRightButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "按钮已触发，跳转网页B", Toast.LENGTH_SHORT).show();
                String url = "http://149.88.82.194/guo/jw.php";
                Intent webIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                Intent chooser = Intent.createChooser(webIntent, "选择浏览器打开");
                startActivity(chooser);
            }
        });
    }

    private void showFileInputDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("输入文件路径");

        LayoutInflater inflater = LayoutInflater.from(this);
        View dialogView = inflater.inflate(R.layout.dialog_file_input, null);
        builder.setView(dialogView);

        final EditText filePathEditText = (EditText) dialogView.findViewById(R.id.editTextFilePath);
        Button btnConfirm = (Button) dialogView.findViewById(R.id.btn_confirm);
        Button btnCancel = (Button) dialogView.findViewById(R.id.btn_cancel);

        String defaultPath = Environment.getExternalStorageDirectory().getPath() +
                           "/-云更新网盘/上号器配置/数据.txt";
        filePathEditText.setText(defaultPath);

        final AlertDialog dialog = builder.create();

        btnConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String filePath = filePathEditText.getText().toString().trim();
                if (!filePath.isEmpty()) {
                    SharedPreferences sharedPreferences = getSharedPreferences("myPrefs", MODE_PRIVATE);
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putString("last_test_file_path", filePath);
                    editor.apply();

                    checkOverlayPermissionAndStart(filePath);
                    dialog.dismiss();
                } else {
                    Toast.makeText(MainActivity.this, "请输入文件路径", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        dialog.show();
    }

    private void checkOverlayPermissionAndStart(String filePath) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "请授予悬浮窗权限", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                         Uri.parse("package:" + getPackageName()));
                startActivityForResult(intent, 100);
                SharedPreferences sharedPreferences = getSharedPreferences("myPrefs", MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString("pending_test_file_path", filePath);
                editor.apply();
            } else {
                startFloatingWindowService(filePath);
            }
        } else {
            startFloatingWindowService(filePath);
        }
    }

    private void startFloatingWindowService(String filePath) {
        Intent serviceIntent = new Intent(MainActivity.this, FloatingWindowService.class);
        serviceIntent.putExtra("source_file_path", filePath);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent);
        } else {
            startService(serviceIntent);
        }

        Toast.makeText(this, "悬浮窗已启动", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 100) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (Settings.canDrawOverlays(this)) {
                    SharedPreferences sharedPreferences = getSharedPreferences("myPrefs", MODE_PRIVATE);
                    String pendingFilePath = sharedPreferences.getString("pending_test_file_path",
                        Environment.getExternalStorageDirectory().getPath() +
                        "/-云更新网盘/上号器配置/数据.txt");

                    if (!pendingFilePath.isEmpty()) {
                        startFloatingWindowService(pendingFilePath);
                        SharedPreferences.Editor editor = sharedPreferences.edit();
                        editor.remove("pending_test_file_path");
                        editor.apply();
                    }
                } else {
                    Toast.makeText(this, "悬浮窗权限被拒绝", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

    private void loadSavedMode() {
        SharedPreferences sharedPreferences = getSharedPreferences("myPrefs", MODE_PRIVATE);
        String mode = sharedPreferences.getString("pd_key", "capture");

        if ("login".equals(mode)) {
            radioLoginMode.setChecked(true);
        } else if ("capture".equals(mode)) {
            radioCaptureMode.setChecked(true);
        } else if ("hang_up".equals(mode)) {
            radioHangUpMode.setChecked(true);
        }
    }

    private void loadSelectedGame() {
        SharedPreferences sharedPreferences = getSharedPreferences("myPrefs", MODE_PRIVATE);
        selectedGameUrl = sharedPreferences.getString(SELECTED_GAME_URL_KEY, "");
        selectedGameName = sharedPreferences.getString(SELECTED_GAME_NAME_KEY, "");
    }

    private void updateSelectGameButtonText() {
        if (!selectedGameName.isEmpty()) {
            selectGameButton.setText("选择游戏 (当前: " + selectedGameName + ")");
        } else {
            selectGameButton.setText("选择游戏");
        }
    }

    private void saveMode(String mode) {
        SharedPreferences sharedPreferences = getSharedPreferences("myPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("pd_key", mode);
        editor.apply();
    }

    private void saveSelectedGame(String gameName, String gameUrl) {
        SharedPreferences sharedPreferences = getSharedPreferences("myPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(SELECTED_GAME_URL_KEY, gameUrl);
        editor.putString(SELECTED_GAME_NAME_KEY, gameName);
        editor.apply();

        selectedGameName = gameName;
        selectedGameUrl = gameUrl;
        updateSelectGameButtonText();

        Toast.makeText(this, "已选择游戏: " + gameName, Toast.LENGTH_SHORT).show();
    }

    private void showGameSelectionDialog() {
        if (gameList.isEmpty()) {
            Toast.makeText(this, "正在加载游戏列表，请稍后...", Toast.LENGTH_SHORT).show();
            loadGameListFromServer();
            return;
        }

        final String[] gameNames = new String[gameList.size()];
        for (int i = 0; i < gameList.size(); i++) {
            gameNames[i] = gameList.get(i).name;
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("选择游戏");
        builder.setItems(gameNames, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                GameItem selectedGame = gameList.get(which);
                saveSelectedGame(selectedGame.name, selectedGame.url);
            }
        });
        builder.show();
    }

    private void loadGameListFromServer() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                String responseData = "";

                try {
                    URL url = new URL("https://qq.888888a.cn/QQgame.php");
                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("GET");
                    connection.setConnectTimeout(5000);
                    connection.setReadTimeout(5000);

                    InputStream inputStream = connection.getInputStream();
                    java.util.Scanner scanner = new java.util.Scanner(inputStream).useDelimiter("\\A");
                    responseData = scanner.hasNext() ? scanner.next() : "";
                    scanner.close();
                    inputStream.close();

                } catch (Exception e) {
                    e.printStackTrace();
                }

                final String finalResponse = responseData;

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        parseGameData(finalResponse);
                        if (!gameList.isEmpty() && selectedGameName.isEmpty()) {
                            GameItem firstGame = gameList.get(0);
                            saveSelectedGame(firstGame.name, firstGame.url);
                        }
                    }
                });
            }
        }).start();
    }

    private void parseGameData(String data) {
        if (data == null || data.isEmpty()) {
            return;
        }

        gameList.clear();

        Pattern pattern = Pattern.compile("图标：(.*?)；名称：(.*?)；链接：〖链接(.*?)〗；");
        Matcher matcher = pattern.matcher(data);

        while (matcher.find()) {
            String iconUrl = matcher.group(1).trim();
            String name = matcher.group(2).trim();
            String url = matcher.group(3).trim();

            gameList.add(new GameItem(iconUrl, name, url));
        }

        if (gameList.isEmpty()) {
            Toast.makeText(this, "未找到游戏数据", Toast.LENGTH_SHORT).show();
        }
    }

    private void hidePackage(String packageName) throws IOException {
        Process process = Runtime.getRuntime().exec("su");
        DataOutputStream outputStream = new DataOutputStream(process.getOutputStream());
        outputStream.writeBytes("pm hide " + packageName + "\n");
        outputStream.writeBytes("exit\n");
        outputStream.flush();
        outputStream.close();
        try {
            process.waitFor();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private void unhidePackage(String packageName) throws IOException {
        Process process = Runtime.getRuntime().exec("su");
        DataOutputStream outputStream = new DataOutputStream(process.getOutputStream());
        outputStream.writeBytes("pm unhide " + packageName + "\n");
        outputStream.writeBytes("exit\n");
        outputStream.flush();
        outputStream.close();
        try {
            process.waitFor();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}