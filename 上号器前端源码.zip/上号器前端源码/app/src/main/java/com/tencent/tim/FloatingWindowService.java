package com.tencent.tim;

import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.IBinder;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.content.ClipboardManager;
import android.content.ClipData;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.List;
import java.util.ArrayList;
import android.os.Environment;

public class FloatingWindowService extends Service {
    
    private WindowManager windowManager;
    private View floatingView;
    private TextView dataTextView;
    private Button saveButton;
    private Button deleteButton;
    private Button closeButton;
    
    private List<String> dataList = new ArrayList<>();
    private int currentIndex = 0;
    private String sourceFilePath = "";
    private String targetFilePath = "";
    
    // 悬浮窗参数
    private WindowManager.LayoutParams params;
    
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    
    @Override
    public void onCreate() {
        super.onCreate();
        
        // 初始化文件路径
        sourceFilePath = Environment.getExternalStorageDirectory().getPath() + 
                        "/-云更新网盘/上号器配置/数据.txt";
        targetFilePath = Environment.getExternalStorageDirectory().getPath() + 
                        "/-云更新网盘/上号器配置/筛选.txt";
        
        // 创建悬浮窗
        createFloatingWindow();
    }
    
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            // 如果有传递文件路径，使用传递的路径
            String customPath = intent.getStringExtra("source_file_path");
            if (customPath != null && !customPath.isEmpty()) {
                sourceFilePath = customPath;
            }
        }
        
        // 加载数据
        loadDataFromFile();
        
        return START_STICKY;
    }
    
    private void createFloatingWindow() {
        try {
            // 获取WindowManager
            windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
            
            // 创建自定义布局（不使用XML）
            floatingView = createFloatingView();
            
            // 设置窗口参数
            int type;
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
            } else {
                type = WindowManager.LayoutParams.TYPE_PHONE;
            }
            
            params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
            
            // 设置位置
            params.gravity = Gravity.TOP | Gravity.START;
            params.x = 80;
            params.y = 80;
            
            // 添加视图到窗口
            windowManager.addView(floatingView, params);
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    private View createFloatingView() {
        // 创建主布局
        android.widget.LinearLayout mainLayout = new android.widget.LinearLayout(this);
        mainLayout.setOrientation(android.widget.LinearLayout.VERTICAL);
        mainLayout.setBackgroundColor(android.graphics.Color.parseColor("#3F51B5"));
        mainLayout.setPadding(4, 4, 4, 4);  // 缩短1/3：6 -> 4
        
        // 拖动区域（标题栏）- 缩短1/3
        android.widget.LinearLayout dragLayout = new android.widget.LinearLayout(this);
        dragLayout.setOrientation(android.widget.LinearLayout.HORIZONTAL);
        dragLayout.setBackgroundColor(android.graphics.Color.parseColor("#303F9F"));
        dragLayout.setPadding(5, 5, 5, 5);  // 缩短1/3：8 -> 5
        dragLayout.setLayoutParams(new android.widget.LinearLayout.LayoutParams(
            android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
            android.widget.LinearLayout.LayoutParams.WRAP_CONTENT));
        
        TextView titleView = new TextView(this);
        titleView.setText("验号悬浮窗");
        titleView.setTextColor(android.graphics.Color.WHITE);
        titleView.setTextSize(9);  // 缩短1/3：11 -> 9
        
        dragLayout.addView(titleView);
        
        // 设置拖动事件
        dragLayout.setOnTouchListener(new View.OnTouchListener() {
            private int initialX;
            private int initialY;
            private float initialTouchX;
            private float initialTouchY;
            
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = params.x;
                        initialY = params.y;
                        initialTouchX = event.getRawX();
                        initialTouchY = event.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        params.x = initialX + (int) (event.getRawX() - initialTouchX);
                        params.y = initialY + (int) (event.getRawY() - initialTouchY);
                        windowManager.updateViewLayout(floatingView, params);
                        return true;
                }
                return false;
            }
        });
        
        // 数据展示区域 - 缩短1/3
        android.widget.LinearLayout dataLayout = new android.widget.LinearLayout(this);
        dataLayout.setOrientation(android.widget.LinearLayout.HORIZONTAL);
        dataLayout.setBackgroundColor(android.graphics.Color.WHITE);
        dataLayout.setPadding(5, 5, 5, 5);  // 缩短1/3：8 -> 5
        dataLayout.setLayoutParams(new android.widget.LinearLayout.LayoutParams(
            android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
            android.widget.LinearLayout.LayoutParams.WRAP_CONTENT));
        
        dataTextView = new TextView(this);
        dataTextView.setLayoutParams(new android.widget.LinearLayout.LayoutParams(
            android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
            android.widget.LinearLayout.LayoutParams.WRAP_CONTENT));
        dataTextView.setText("无数据");
        dataTextView.setTextColor(android.graphics.Color.BLACK);
        dataTextView.setTextSize(10);  // 缩短1/3：13 -> 10
        dataTextView.setPadding(5, 5, 5, 5);  // 缩短1/3：8 -> 5
        dataTextView.setBackgroundColor(android.graphics.Color.parseColor("#F5F5F5"));
        dataTextView.setSingleLine(true);
        dataTextView.setEllipsize(null);
        dataTextView.setMinHeight(32);  // 缩短1/3：48 -> 32
        
        // 设置点击复制功能
        dataTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String currentData = dataTextView.getText().toString();
                if (!currentData.isEmpty() && !"无数据".equals(currentData)) {
                    ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                    ClipData clip = ClipData.newPlainText("验号数据", currentData);
                    clipboard.setPrimaryClip(clip);
                    Toast.makeText(FloatingWindowService.this, "已复制", Toast.LENGTH_SHORT).show();
                }
            }
        });
        
        dataLayout.addView(dataTextView);
        
        // 按钮区域 - 缩短1/3
        android.widget.LinearLayout buttonLayout = new android.widget.LinearLayout(this);
        buttonLayout.setOrientation(android.widget.LinearLayout.HORIZONTAL);
        buttonLayout.setLayoutParams(new android.widget.LinearLayout.LayoutParams(
            android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
            android.widget.LinearLayout.LayoutParams.WRAP_CONTENT));
        buttonLayout.setPadding(0, 5, 0, 0);  // 缩短1/3：8 -> 5
        
        // 保存按钮
        saveButton = new Button(this);
        saveButton.setText("保存");
        saveButton.setTextColor(android.graphics.Color.WHITE);
        saveButton.setBackgroundColor(android.graphics.Color.parseColor("#4CAF50"));
        saveButton.setPadding(10, 5, 10, 5);  // 缩短1/3：16,8,16,8 -> 10,5,10,5
        saveButton.setTextSize(9);  // 缩短1/3：11 -> 9
        android.widget.LinearLayout.LayoutParams saveParams = new android.widget.LinearLayout.LayoutParams(
            0, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT);
        saveParams.weight = 1;
        saveParams.setMargins(1, 0, 1, 0);  // 缩短1/3：2 -> 1
        saveButton.setLayoutParams(saveParams);
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveCurrentData();
            }
        });
        
        // 删除按钮
        deleteButton = new Button(this);
        deleteButton.setText("删除");
        deleteButton.setTextColor(android.graphics.Color.WHITE);
        deleteButton.setBackgroundColor(android.graphics.Color.parseColor("#F44336"));
        deleteButton.setPadding(10, 5, 10, 5);  // 缩短1/3：16,8,16,8 -> 10,5,10,5
        deleteButton.setTextSize(9);  // 缩短1/3：11 -> 9
        android.widget.LinearLayout.LayoutParams deleteParams = new android.widget.LinearLayout.LayoutParams(
            0, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT);
        deleteParams.weight = 1;
        deleteParams.setMargins(1, 0, 1, 0);  // 缩短1/3：2 -> 1
        deleteButton.setLayoutParams(deleteParams);
        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteCurrentData();
            }
        });
        
        // 关闭按钮
        closeButton = new Button(this);
        closeButton.setText("关闭");
        closeButton.setTextColor(android.graphics.Color.WHITE);
        closeButton.setBackgroundColor(android.graphics.Color.parseColor("#2196F3"));
        closeButton.setPadding(10, 5, 10, 5);  // 缩短1/3：16,8,16,8 -> 10,5,10,5
        closeButton.setTextSize(9);  // 缩短1/3：11 -> 9
        android.widget.LinearLayout.LayoutParams closeParams = new android.widget.LinearLayout.LayoutParams(
            0, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT);
        closeParams.weight = 1;
        closeParams.setMargins(1, 0, 1, 0);  // 缩短1/3：2 -> 1
        closeButton.setLayoutParams(closeParams);
        closeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopSelf();
            }
        });
        
        // 添加按钮到布局
        buttonLayout.addView(saveButton);
        buttonLayout.addView(deleteButton);
        buttonLayout.addView(closeButton);
        
        // 添加到主布局
        mainLayout.addView(dragLayout);
        mainLayout.addView(dataLayout);
        mainLayout.addView(buttonLayout);
        
        return mainLayout;
    }
    
    private void loadDataFromFile() {
        try {
            File file = new File(sourceFilePath);
            if (!file.exists()) {
                dataTextView.setText("文件不存在");
                return;
            }
            
            BufferedReader reader = new BufferedReader(new FileReader(file));
            String line;
            dataList.clear();
            
            while ((line = reader.readLine()) != null) {
                if (!line.trim().isEmpty()) {
                    dataList.add(line.trim());
                }
            }
            reader.close();
            
            if (dataList.isEmpty()) {
                dataTextView.setText("无数据");
                saveButton.setEnabled(false);
                deleteButton.setEnabled(false);
            } else {
                currentIndex = 0;
                showCurrentData();
            }
            
        } catch (IOException e) {
            e.printStackTrace();
            dataTextView.setText("读取失败");
            saveButton.setEnabled(false);
            deleteButton.setEnabled(false);
        }
    }
    
    private void showCurrentData() {
        if (currentIndex < dataList.size()) {
            String data = dataList.get(currentIndex);
            
            // 显示完整的原始数据，从第一个字符到最后一个字符
            // 所有内容显示在同一行
            dataTextView.setText(data);
            dataTextView.setSingleLine(true);
            dataTextView.setEllipsize(null);
            
            saveButton.setEnabled(true);
            deleteButton.setEnabled(true);
        } else {
            dataTextView.setText("已完成");
            saveButton.setEnabled(false);
            deleteButton.setEnabled(false);
        }
    }
    
    private void saveCurrentData() {
        if (currentIndex < dataList.size()) {
            String dataToSave = dataList.get(currentIndex);
            
            try {
                // 确保目录存在
                File targetFile = new File(targetFilePath);
                File parentDir = targetFile.getParentFile();
                if (!parentDir.exists()) {
                    parentDir.mkdirs();
                }
                
                // 追加写入文件
                FileWriter writer = new FileWriter(targetFile, true);
                writer.write(dataToSave + "\n");
                writer.close();
                
                Toast.makeText(this, "已保存", Toast.LENGTH_SHORT).show();
                
                // 删除当前数据并显示下一行
                deleteCurrentData();
                
            } catch (IOException e) {
                e.printStackTrace();
                Toast.makeText(this, "保存失败", Toast.LENGTH_SHORT).show();
            }
        }
    }
    
    private void deleteCurrentData() {
        if (currentIndex < dataList.size()) {
            dataList.remove(currentIndex);
            
            if (dataList.isEmpty()) {
                dataTextView.setText("已完成");
                saveButton.setEnabled(false);
                deleteButton.setEnabled(false);
                Toast.makeText(this, "已完成所有数据", Toast.LENGTH_SHORT).show();
            } else {
                if (currentIndex >= dataList.size()) {
                    currentIndex = Math.max(0, dataList.size() - 1);
                }
                showCurrentData();
            }
        }
    }
    
    @Override
    public void onDestroy() {
        super.onDestroy();
        if (floatingView != null && windowManager != null) {
            windowManager.removeView(floatingView);
        }
    }
}