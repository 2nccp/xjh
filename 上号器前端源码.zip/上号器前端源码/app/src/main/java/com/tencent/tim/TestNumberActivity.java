package com.tencent.tim;

import android.app.Activity;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Button;
import android.view.View;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.graphics.Color;
import android.util.DisplayMetrics;
import android.content.ClipboardManager;
import android.content.ClipData;
import android.widget.Toast;
import android.content.Intent;
import android.provider.Settings;
import android.net.Uri;
import android.os.Build;
import android.app.AlertDialog;
import android.content.DialogInterface;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.List;
import java.util.ArrayList;
import android.os.Environment;

public class TestNumberActivity extends Activity {
    
    private TextView dataTextView;
    private Button saveButton;
    private Button deleteButton;
    private Button closeButton;
    private List<String> dataList = new ArrayList<>();
    private int currentIndex = 0;
    private String sourceFilePath = "";
    private String targetFilePath = "";
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // 获取传递的文件路径
        Intent intent = getIntent();
        if (intent != null) {
            sourceFilePath = intent.getStringExtra("source_file_path");
            targetFilePath = Environment.getExternalStorageDirectory().getPath() + 
                           "/-云更新网盘/上号器配置/筛选.txt";
        }
        
        // 设置为悬浮窗样式
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                           WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE);
        
        // 获取屏幕尺寸
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int screenWidth = displayMetrics.widthPixels;
        int screenHeight = displayMetrics.heightPixels;
        
        // 设置窗口属性
        WindowManager.LayoutParams params = getWindow().getAttributes();
        params.width = (int)(screenWidth * 0.6);  // 缩短1/3：0.72 -> 0.6
        params.height = WindowManager.LayoutParams.WRAP_CONTENT;
        params.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        params.x = (int)(screenWidth * 0.2);  // 缩短1/3：0.14 -> 0.2
        params.y = 100;  // 缩短1/3：160 -> 100
        params.flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL |
                      WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                      WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        getWindow().setAttributes(params);
        
        // 创建布局
        LinearLayout mainLayout = new LinearLayout(this);
        mainLayout.setOrientation(LinearLayout.VERTICAL);
        mainLayout.setBackgroundColor(Color.parseColor("#3F51B5"));
        mainLayout.setPadding(5, 10, 5, 10);  // 缩短1/3：8,16,8,16 -> 5,10,5,10
        
        // 标题栏
        LinearLayout titleLayout = new LinearLayout(this);
        titleLayout.setOrientation(LinearLayout.HORIZONTAL);
        titleLayout.setBackgroundColor(Color.parseColor("#303F9F"));
        titleLayout.setPadding(5, 5, 5, 5);  // 缩短1/3：8 -> 5
        
        TextView titleTextView = new TextView(this);
        titleTextView.setText("验号悬浮窗");
        titleTextView.setTextSize(10);  // 缩短1/3：13 -> 10
        titleTextView.setTextColor(Color.WHITE);
        titleTextView.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT));
        
        titleLayout.addView(titleTextView);
        
        // 数据展示区域
        LinearLayout dataLayout = new LinearLayout(this);
        dataLayout.setOrientation(LinearLayout.VERTICAL);
        dataLayout.setBackgroundColor(Color.WHITE);
        dataLayout.setPadding(8, 8, 8, 8);  // 缩短1/3：12 -> 8
        dataLayout.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT));
        
        TextView dataTitle = new TextView(this);
        dataTitle.setText("当前数据:");
        dataTitle.setTextSize(9);  // 缩短1/3：11 -> 9
        dataTitle.setTextColor(Color.GRAY);
        dataTitle.setPadding(0, 0, 0, 5);  // 缩短1/3：8 -> 5
        
        dataTextView = new TextView(this);
        dataTextView.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT));
        dataTextView.setTextSize(11);  // 缩短1/3：14 -> 11
        dataTextView.setTextColor(Color.BLACK);
        dataTextView.setPadding(5, 5, 5, 5);  // 缩短1/3：8 -> 5
        dataTextView.setBackgroundColor(Color.parseColor("#F5F5F5"));
        dataTextView.setMinHeight(64);  // 缩短1/3：96 -> 64
        dataTextView.setGravity(Gravity.CENTER);
        dataTextView.setSingleLine(true);
        dataTextView.setEllipsize(null);
        
        // 设置点击复制功能
        dataTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String currentData = dataTextView.getText().toString();
                if (!currentData.isEmpty() && !"无数据".equals(currentData)) {
                    ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                    ClipData clip = ClipData.newPlainText("验号数据", currentData);
                    clipboard.setPrimaryClip(clip);
                    Toast.makeText(TestNumberActivity.this, "已复制", Toast.LENGTH_SHORT).show();
                }
            }
        });
        
        dataLayout.addView(dataTitle);
        dataLayout.addView(dataTextView);
        
        // 按钮布局
        LinearLayout buttonLayout = new LinearLayout(this);
        buttonLayout.setOrientation(LinearLayout.HORIZONTAL);
        buttonLayout.setGravity(Gravity.CENTER);
        buttonLayout.setPadding(0, 10, 0, 0);  // 缩短1/3：16 -> 10
        
        // 保存按钮
        saveButton = new Button(this);
        saveButton.setText("保存");
        saveButton.setTextColor(Color.WHITE);
        saveButton.setBackgroundColor(Color.parseColor("#4CAF50"));
        saveButton.setPadding(16, 8, 16, 8);  // 缩短1/3：24,12,24,12 -> 16,8,16,8
        saveButton.setTextSize(10);  // 缩短1/3：13 -> 10
        LinearLayout.LayoutParams saveParams = new LinearLayout.LayoutParams(
            0, LinearLayout.LayoutParams.WRAP_CONTENT);
        saveParams.weight = 1;
        saveParams.setMargins(3, 0, 3, 0);  // 缩短1/3：4 -> 3
        saveButton.setLayoutParams(saveParams);
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveCurrentData();
            }
        });
        
        // 删除按钮
        deleteButton = new Button(this);
        deleteButton.setText("删除");
        deleteButton.setTextColor(Color.WHITE);
        deleteButton.setBackgroundColor(Color.parseColor("#F44336"));
        deleteButton.setPadding(16, 8, 16, 8);  // 缩短1/3：24,12,24,12 -> 16,8,16,8
        deleteButton.setTextSize(10);  // 缩短1/3：13 -> 10
        LinearLayout.LayoutParams deleteParams = new LinearLayout.LayoutParams(
            0, LinearLayout.LayoutParams.WRAP_CONTENT);
        deleteParams.weight = 1;
        deleteParams.setMargins(3, 0, 3, 0);  // 缩短1/3：4 -> 3
        deleteButton.setLayoutParams(deleteParams);
        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteCurrentData();
            }
        });
        
        // 关闭按钮
        closeButton = new Button(this);
        closeButton.setText("关闭");
        closeButton.setTextColor(Color.WHITE);
        closeButton.setBackgroundColor(Color.parseColor("#2196F3"));
        closeButton.setPadding(16, 8, 16, 8);  // 缩短1/3：24,12,24,12 -> 16,8,16,8
        closeButton.setTextSize(10);  // 缩短1/3：13 -> 10
        LinearLayout.LayoutParams closeParams = new LinearLayout.LayoutParams(
            0, LinearLayout.LayoutParams.WRAP_CONTENT);
        closeParams.weight = 1;
        closeParams.setMargins(3, 0, 3, 0);  // 缩短1/3：4 -> 3
        closeButton.setLayoutParams(closeParams);
        closeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        
        // 添加按钮到布局
        buttonLayout.addView(saveButton);
        buttonLayout.addView(deleteButton);
        buttonLayout.addView(closeButton);
        
        // 添加到主布局
        mainLayout.addView(titleLayout);
        mainLayout.addView(dataLayout);
        mainLayout.addView(buttonLayout);
        
        setContentView(mainLayout);
        
        // 加载数据
        if (sourceFilePath != null && !sourceFilePath.isEmpty()) {
            loadDataFromFile();
        } else {
            dataTextView.setText("无数据");
        }
    }
    
    private void loadDataFromFile() {
        try {
            File file = new File(sourceFilePath);
            if (!file.exists()) {
                dataTextView.setText("文件不存在");
                return;
            }
            
            BufferedReader reader = new BufferedReader(new FileReader(file));
            String line;
            dataList.clear();
            
            while ((line = reader.readLine()) != null) {
                if (!line.trim().isEmpty()) {
                    dataList.add(line.trim());
                }
            }
            reader.close();
            
            if (dataList.isEmpty()) {
                dataTextView.setText("无数据");
                saveButton.setEnabled(false);
                deleteButton.setEnabled(false);
            } else {
                currentIndex = 0;
                showCurrentData();
            }
            
        } catch (IOException e) {
            e.printStackTrace();
            dataTextView.setText("读取失败");
            saveButton.setEnabled(false);
            deleteButton.setEnabled(false);
        }
    }
    
    private void showCurrentData() {
        if (currentIndex < dataList.size()) {
            String data = dataList.get(currentIndex);
            
            // 显示完整的原始数据，从第一个字符到最后一个字符
            // 所有内容显示在同一行
            dataTextView.setText(data);
            dataTextView.setSingleLine(true);
            dataTextView.setEllipsize(null);
            
            saveButton.setEnabled(true);
            deleteButton.setEnabled(true);
        } else {
            dataTextView.setText("已完成");
            saveButton.setEnabled(false);
            deleteButton.setEnabled(false);
        }
    }
    
    private void saveCurrentData() {
        if (currentIndex < dataList.size()) {
            String dataToSave = dataList.get(currentIndex);
            
            try {
                // 确保目录存在
                File targetFile = new File(targetFilePath);
                File parentDir = targetFile.getParentFile();
                if (!parentDir.exists()) {
                    parentDir.mkdirs();
                }
                
                // 追加写入文件
                FileWriter writer = new FileWriter(targetFile, true);
                writer.write(dataToSave + "\n");
                writer.close();
                
                Toast.makeText(this, "已保存", Toast.LENGTH_SHORT).show();
                
                // 删除当前数据并显示下一行
                deleteCurrentData();
                
            } catch (IOException e) {
                e.printStackTrace();
                Toast.makeText(this, "保存失败", Toast.LENGTH_SHORT).show();
            }
        }
    }
    
    private void deleteCurrentData() {
        if (currentIndex < dataList.size()) {
            dataList.remove(currentIndex);
            
            if (dataList.isEmpty()) {
                dataTextView.setText("已完成");
                saveButton.setEnabled(false);
                deleteButton.setEnabled(false);
                Toast.makeText(this, "已完成所有数据", Toast.LENGTH_SHORT).show();
            } else {
                if (currentIndex >= dataList.size()) {
                    currentIndex = Math.max(0, dataList.size() - 1);
                }
                showCurrentData();
            }
        }
    }
}